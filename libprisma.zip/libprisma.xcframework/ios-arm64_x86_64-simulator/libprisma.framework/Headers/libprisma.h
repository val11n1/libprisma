//
//  libprisma.h
//  libprisma
//
//  Created by vtrusov on 01.12.2024.
//

#import <Foundation/Foundation.h>

//! Project version number for libprisma.
FOUNDATION_EXPORT double libprismaVersionNumber;

//! Project version string for libprisma.
FOUNDATION_EXPORT const unsigned char libprismaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <libprisma/PublicHeader.h>


#import <libprisma/Syntaxer.h>
